package finalStake.exception.authentication;

import lombok.experimental.StandardException;

@StandardException
public class InvalidTokenTypeException extends RuntimeException {
}
