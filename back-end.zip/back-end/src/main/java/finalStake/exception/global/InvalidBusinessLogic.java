package finalStake.exception.global;

import lombok.experimental.StandardException;

@StandardException
public class InvalidBusinessLogic extends RuntimeException {
}
