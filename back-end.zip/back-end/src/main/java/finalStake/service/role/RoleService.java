package finalStake.service.role;

import java.util.List;

public interface RoleService {
    List<String> getAllRoles();
}
