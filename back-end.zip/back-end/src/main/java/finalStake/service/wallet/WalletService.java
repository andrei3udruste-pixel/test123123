package finalStake.service.wallet;

import finalStake.dto.wallet.WalletViewDTO;

public interface WalletService {
    WalletViewDTO getMyWallet();
}
