import {
  MatFormFieldModule
} from "./chunk-IJBV3HN3.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-EBT5CX72.js";
import "./chunk-7KEO4V5Y.js";
import "./chunk-42QFQP6S.js";
import "./chunk-VON75VBJ.js";
import "./chunk-L2JIADS7.js";
import "./chunk-DPAJNIXH.js";
import "./chunk-CU5DZDC4.js";
import "./chunk-ZTXPRV2E.js";
import "./chunk-RXRFP2MK.js";
import "./chunk-N4DOILP3.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-D3BV26EE.js";
import "./chunk-MO65O3YO.js";
import "./chunk-YQ754TUL.js";
import "./chunk-24QLWJP7.js";
import "./chunk-EOZTNN33.js";
import "./chunk-2E5A4YC3.js";
import "./chunk-FEPTOOVB.js";
import "./chunk-WYF26C5D.js";
import "./chunk-WDMUDEB6.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
