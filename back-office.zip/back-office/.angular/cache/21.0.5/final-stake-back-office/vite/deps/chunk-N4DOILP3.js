// node_modules/@angular/cdk/fesm2022/_array-chunk.mjs
function coerceArray(value) {
  return Array.isArray(value) ? value : [value];
}

export {
  coerceArray
};
//# sourceMappingURL=chunk-N4DOILP3.js.map
